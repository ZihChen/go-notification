{{- define "redis.name" -}}
{{ .Release.Name }}-redis
{{- end -}}
